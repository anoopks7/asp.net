# AspNetCore-Docker
ASP.NET Core app used for demoing CI/CD and Docker in Udemy course: https://www.udemy.com/course/devops-using-vsts-docker-azure

Course available on Udemy: https://www.udemy.com/course/devops-using-vsts-docker-azure
